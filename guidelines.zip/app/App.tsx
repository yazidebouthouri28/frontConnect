import { useState } from 'react';
import { Navigation } from '@/app/components/navigation';
import { HeroSection } from '@/app/components/hero-section';
import { CampsiteListings } from '@/app/components/campsite-listings';
import { CommunityForum } from '@/app/components/community-forum';
import { EventsManagement } from '@/app/components/events-management';
import { Marketplace } from '@/app/components/marketplace';
import { InteractiveMap } from '@/app/components/interactive-map';
import { UserDashboard } from '@/app/components/user-dashboard';
import { Footer } from '@/app/components/footer';
import { AdminPanel } from '@/app/components/admin/admin-panel';

export default function App() {
  // Pour basculer entre l'interface utilisateur et l'admin
  // En production, cela serait géré par le routing et l'authentification
  const [isAdminMode, setIsAdminMode] = useState(false);

  // Si en mode admin, afficher le panneau d'administration
  if (isAdminMode) {
    return <AdminPanel />;
  }

  // Sinon, afficher l'interface utilisateur normale
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      {/* Bouton temporaire pour accéder à l'admin (à retirer en production) */}
      <button
        onClick={() => setIsAdminMode(true)}
        className="fixed bottom-4 right-4 z-50 bg-[#2C4A3C] text-[#F5F2E8] px-4 py-2 rounded-lg shadow-lg hover:bg-[#5D7B5F] transition-colors text-sm"
      >
        🔐 Mode Admin
      </button>

      <main className="flex-1">
        <HeroSection />
        <CampsiteListings />
        <CommunityForum />
        <EventsManagement />
        <Marketplace />
        <InteractiveMap />
        <UserDashboard />
      </main>
      <Footer />
    </div>
  );
}
