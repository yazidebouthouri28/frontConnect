import { Mountain, ShoppingCart, User, Menu } from 'lucide-react';
import { useState } from 'react';

export function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#5D7B5F]/20 bg-[#2C4A3C] shadow-sm">
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Mountain className="h-8 w-8 text-[#F5F2E8]" />
            <span className="text-xl font-bold text-[#F5F2E8]">CampConnect</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-[#F5F2E8] hover:text-[#A8B9A3] transition-colors">
              Home
            </a>
            <a href="#campsites" className="text-[#F5F2E8] hover:text-[#A8B9A3] transition-colors">
              Campsites
            </a>
            <a href="#marketplace" className="text-[#F5F2E8] hover:text-[#A8B9A3] transition-colors">
              Marketplace
            </a>
            <a href="#events" className="text-[#F5F2E8] hover:text-[#A8B9A3] transition-colors">
              Events
            </a>
            <a href="#community" className="text-[#F5F2E8] hover:text-[#A8B9A3] transition-colors">
              Community
            </a>
            <a href="#map" className="text-[#F5F2E8] hover:text-[#A8B9A3] transition-colors">
              Map
            </a>
          </div>

          {/* Right Side Icons */}
          <div className="flex items-center gap-4">
            <button className="text-[#F5F2E8] hover:text-[#A8B9A3] transition-colors">
              <ShoppingCart className="h-6 w-6" />
            </button>
            <button className="text-[#F5F2E8] hover:text-[#A8B9A3] transition-colors">
              <User className="h-6 w-6" />
            </button>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-[#F5F2E8]"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2 border-t border-[#5D7B5F]/20">
            <a href="#home" className="block py-2 text-[#F5F2E8] hover:text-[#A8B9A3]">
              Home
            </a>
            <a href="#campsites" className="block py-2 text-[#F5F2E8] hover:text-[#A8B9A3]">
              Campsites
            </a>
            <a href="#marketplace" className="block py-2 text-[#F5F2E8] hover:text-[#A8B9A3]">
              Marketplace
            </a>
            <a href="#events" className="block py-2 text-[#F5F2E8] hover:text-[#A8B9A3]">
              Events
            </a>
            <a href="#community" className="block py-2 text-[#F5F2E8] hover:text-[#A8B9A3]">
              Community
            </a>
            <a href="#map" className="block py-2 text-[#F5F2E8] hover:text-[#A8B9A3]">
              Map
            </a>
          </div>
        )}
      </nav>
    </header>
  );
}
