import { Calendar, Package, Award, MessageCircle, MapPin, Heart, Star } from 'lucide-react';
import { useState } from 'react';

interface TabType {
  id: string;
  label: string;
  icon: any;
}

const tabs: TabType[] = [
  { id: 'bookings', label: 'My Bookings', icon: Calendar },
  { id: 'purchases', label: 'Orders & Rentals', icon: Package },
  { id: 'rewards', label: 'Loyalty Rewards', icon: Award },
  { id: 'events', label: 'My Events', icon: Calendar },
  { id: 'saved', label: 'Saved Locations', icon: Heart },
  { id: 'forum', label: 'Forum Activity', icon: MessageCircle }
];

const bookingsData = [
  {
    id: 1,
    name: 'Pine Valley Campground',
    location: 'Yosemite National Park, CA',
    checkIn: 'Mar 15, 2026',
    checkOut: 'Mar 18, 2026',
    status: 'Confirmed',
    nights: 3,
    total: 135
  },
  {
    id: 2,
    name: 'Crystal Lake Retreat',
    location: 'Tahoe National Forest, CA',
    checkIn: 'Apr 22, 2026',
    checkOut: 'Apr 25, 2026',
    status: 'Confirmed',
    nights: 3,
    total: 165
  }
];

const ordersData = [
  {
    id: 1,
    item: '4-Person Family Tent',
    type: 'Purchase',
    date: 'Jan 15, 2026',
    price: 299,
    status: 'Delivered'
  },
  {
    id: 2,
    item: 'Premium Sleeping Bag',
    type: 'Rental',
    date: 'Feb 1-7, 2026',
    price: 175,
    status: 'Returned'
  }
];

const rewardsData = {
  currentPoints: 1245,
  tier: 'Gold',
  nextTier: 'Platinum',
  pointsToNext: 755,
  discountRate: 15,
  specialOffers: 3
};

const savedLocations = [
  {
    id: 1,
    name: 'Redwood Grove Campsite',
    location: 'Redwood National Park, CA',
    rating: 4.6
  },
  {
    id: 2,
    name: 'Mountain Peak Base Camp',
    location: 'Rocky Mountain NP, CO',
    rating: 4.7
  }
];

export function UserDashboard() {
  const [activeTab, setActiveTab] = useState('bookings');

  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8 bg-[#A8B9A3]/10">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[#2C4A3C] mb-2">My Dashboard</h2>
          <p className="text-[#5D7B5F]">Manage your camping adventures and rewards</p>
        </div>

        {/* Profile Summary Card */}
        <div className="bg-gradient-to-r from-[#2C4A3C] to-[#5D7B5F] rounded-xl p-6 mb-8 text-[#F5F2E8]">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <div className="w-24 h-24 rounded-full bg-[#F5F2E8] flex items-center justify-center text-[#2C4A3C] text-3xl font-bold">
              JD
            </div>
            <div className="flex-1 text-center md:text-left">
              <h3 className="text-2xl font-bold mb-2">John Doe</h3>
              <p className="text-[#A8B9A3] mb-4">Member since January 2025</p>
              <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                <div className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  <span className="font-semibold">{rewardsData.tier} Member</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 fill-current" />
                  <span>{rewardsData.currentPoints} Points</span>
                </div>
              </div>
            </div>
            <button className="bg-[#F5F2E8] text-[#2C4A3C] px-6 py-2 rounded-lg font-semibold hover:bg-white transition-colors min-h-[44px]">
              Edit Profile
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-6">
          <div className="flex flex-wrap gap-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                    activeTab === tab.id
                      ? 'bg-[#5D7B5F] text-[#F5F2E8]'
                      : 'bg-white text-[#2C4A3C] hover:bg-[#A8B9A3]/20'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab Content */}
        <div className="bg-white rounded-xl p-6 shadow-md border border-[#A8B9A3]/30">
          {activeTab === 'bookings' && (
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-[#2C4A3C] mb-4">Upcoming Bookings</h3>
              {bookingsData.map((booking) => (
                <div key={booking.id} className="border border-[#A8B9A3]/30 rounded-lg p-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <h4 className="font-semibold text-[#2C4A3C] mb-1">{booking.name}</h4>
                      <div className="flex items-center gap-2 text-sm text-[#5D7B5F] mb-2">
                        <MapPin className="h-4 w-4" />
                        <span>{booking.location}</span>
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-[#5D7B5F]">
                        <span>Check-in: {booking.checkIn}</span>
                        <span>Check-out: {booking.checkOut}</span>
                        <span>{booking.nights} nights</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-[#2C4A3C]">${booking.total}</div>
                      <div className="inline-block mt-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold">
                        {booking.status}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'purchases' && (
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-[#2C4A3C] mb-4">Orders & Rentals</h3>
              {ordersData.map((order) => (
                <div key={order.id} className="border border-[#A8B9A3]/30 rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-[#2C4A3C] mb-1">{order.item}</h4>
                    <div className="text-sm text-[#5D7B5F]">
                      <span className="inline-block px-2 py-1 bg-[#A8B9A3]/20 rounded mr-2">{order.type}</span>
                      <span>{order.date}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-[#2C4A3C]">${order.price}</div>
                    <div className="text-sm text-[#5D7B5F]">{order.status}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'rewards' && (
            <div>
              <h3 className="text-xl font-semibold text-[#2C4A3C] mb-6">Loyalty Rewards</h3>
              
              {/* Points Summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-[#A8B9A3]/20 rounded-lg p-4">
                  <div className="text-sm text-[#5D7B5F] mb-1">Current Points</div>
                  <div className="text-3xl font-bold text-[#2C4A3C]">{rewardsData.currentPoints}</div>
                </div>
                <div className="bg-[#A8B9A3]/20 rounded-lg p-4">
                  <div className="text-sm text-[#5D7B5F] mb-1">Member Tier</div>
                  <div className="text-3xl font-bold text-[#2C4A3C]">{rewardsData.tier}</div>
                </div>
                <div className="bg-[#A8B9A3]/20 rounded-lg p-4">
                  <div className="text-sm text-[#5D7B5F] mb-1">Discount Rate</div>
                  <div className="text-3xl font-bold text-[#2C4A3C]">{rewardsData.discountRate}%</div>
                </div>
              </div>

              {/* Progress to Next Tier */}
              <div className="mb-6">
                <div className="flex justify-between text-sm text-[#5D7B5F] mb-2">
                  <span>Progress to {rewardsData.nextTier}</span>
                  <span>{rewardsData.pointsToNext} points to go</span>
                </div>
                <div className="w-full bg-[#A8B9A3]/30 rounded-full h-3">
                  <div
                    className="bg-[#5D7B5F] h-3 rounded-full transition-all"
                    style={{ width: `${(rewardsData.currentPoints / (rewardsData.currentPoints + rewardsData.pointsToNext)) * 100}%` }}
                  />
                </div>
              </div>

              {/* Special Offers */}
              <div>
                <h4 className="font-semibold text-[#2C4A3C] mb-3">Special Member Offers ({rewardsData.specialOffers})</h4>
                <div className="space-y-3">
                  <div className="border border-[#A8B9A3]/30 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h5 className="font-semibold text-[#2C4A3C]">20% Off Next Booking</h5>
                        <p className="text-sm text-[#5D7B5F]">Valid until Feb 28, 2026</p>
                      </div>
                      <button className="bg-[#5D7B5F] text-[#F5F2E8] px-4 py-2 rounded-lg min-h-[44px]">
                        Use Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'saved' && (
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-[#2C4A3C] mb-4">Saved Locations</h3>
              {savedLocations.map((location) => (
                <div key={location.id} className="border border-[#A8B9A3]/30 rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-[#2C4A3C] mb-1">{location.name}</h4>
                    <div className="flex items-center gap-4 text-sm text-[#5D7B5F]">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        <span>{location.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-[#5D7B5F]" />
                        <span>{location.rating}</span>
                      </div>
                    </div>
                  </div>
                  <button className="text-[#5D7B5F] hover:text-[#2C4A3C] font-semibold">
                    View Details →
                  </button>
                </div>
              ))}
            </div>
          )}

          {(activeTab === 'events' || activeTab === 'forum') && (
            <div className="text-center py-12">
              <p className="text-[#5D7B5F]">Content for {tabs.find(t => t.id === activeTab)?.label} coming soon...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
