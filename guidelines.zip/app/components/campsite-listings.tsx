import { Star, Wifi, Flame, Trees, Droplet, Users, MapPin } from 'lucide-react';

interface Campsite {
  id: number;
  name: string;
  location: string;
  image: string;
  rating: number;
  reviews: number;
  price: number;
  amenities: string[];
  distance: number;
}

const campsites: Campsite[] = [
  {
    id: 1,
    name: 'Pine Valley Campground',
    location: 'Yosemite National Park, CA',
    image: 'https://images.unsplash.com/photo-1747447597297-0716bbd5b049?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb3Jlc3QlMjBjYW1wc2l0ZSUyMGFlcmlhbCUyMHZpZXd8ZW58MXx8fHwxNzY5NjEwOTY3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.8,
    reviews: 324,
    price: 45,
    amenities: ['wifi', 'campfire', 'hiking', 'water'],
    distance: 2.5
  },
  {
    id: 2,
    name: 'Crystal Lake Retreat',
    location: 'Tahoe National Forest, CA',
    image: 'https://images.unsplash.com/photo-1763771056927-557d39cb5e02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYWtlc2lkZSUyMGNhbXBpbmclMjB0ZW50JTIwc2NlbmljfGVufDF8fHx8MTc2OTYxMDk2N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.9,
    reviews: 512,
    price: 55,
    amenities: ['wifi', 'campfire', 'water', 'group'],
    distance: 3.2
  },
  {
    id: 3,
    name: 'Mountain Peak Base Camp',
    location: 'Rocky Mountain NP, CO',
    image: 'https://images.unsplash.com/photo-1693954100560-36dbf3d1623c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGNhbXBncm91bmQlMjBmYWNpbGl0aWVzfGVufDF8fHx8MTc2OTYxMDk2N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.7,
    reviews: 289,
    price: 40,
    amenities: ['campfire', 'hiking', 'water'],
    distance: 5.8
  },
  {
    id: 4,
    name: 'Redwood Grove Campsite',
    location: 'Redwood National Park, CA',
    image: 'https://images.unsplash.com/photo-1747447597297-0716bbd5b049?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb3Jlc3QlMjBjYW1wc2l0ZSUyMGFlcmlhbCUyMHZpZXd8ZW58MXx8fHwxNzY5NjEwOTY3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.6,
    reviews: 178,
    price: 38,
    amenities: ['campfire', 'hiking', 'group'],
    distance: 4.3
  },
  {
    id: 5,
    name: 'Sunset Vista Campground',
    location: 'Grand Canyon NP, AZ',
    image: 'https://images.unsplash.com/photo-1763771056927-557d39cb5e02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYWtlc2lkZSUyMGNhbXBpbmclMjB0ZW50JTIwc2NlbmljfGVufDF8fHx8MTc2OTYxMDk2N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.9,
    reviews: 456,
    price: 50,
    amenities: ['wifi', 'campfire', 'hiking', 'water', 'group'],
    distance: 1.8
  },
  {
    id: 6,
    name: 'Riverside Adventure Camp',
    location: 'Zion National Park, UT',
    image: 'https://images.unsplash.com/photo-1693954100560-36dbf3d1623c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGNhbXBncm91bmQlMjBmYWNpbGl0aWVzfGVufDF8fHx8MTc2OTYxMDk2N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.8,
    reviews: 367,
    price: 48,
    amenities: ['wifi', 'water', 'group'],
    distance: 3.7
  }
];

const amenityIcons: Record<string, { icon: any; label: string }> = {
  wifi: { icon: Wifi, label: 'WiFi' },
  campfire: { icon: Flame, label: 'Campfire' },
  hiking: { icon: Trees, label: 'Hiking Trails' },
  water: { icon: Droplet, label: 'Water Access' },
  group: { icon: Users, label: 'Group Friendly' }
};

export function CampsiteListings() {
  return (
    <section id="campsites" className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[#2C4A3C] mb-2">Featured Campsites</h2>
          <p className="text-[#5D7B5F]">Discover your perfect camping destination</p>
        </div>

        {/* Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {campsites.map((campsite) => (
            <div 
              key={campsite.id}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-[#A8B9A3]/30"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={campsite.image}
                  alt={campsite.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full shadow-md">
                  <span className="text-[#2C4A3C] font-semibold">${campsite.price}/night</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <h3 className="text-xl font-semibold text-[#2C4A3C] mb-2">{campsite.name}</h3>
                
                <div className="flex items-center gap-2 text-[#5D7B5F] mb-3">
                  <MapPin className="h-4 w-4" />
                  <span className="text-sm">{campsite.location}</span>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-[#5D7B5F] text-[#5D7B5F]" />
                    <span className="font-semibold text-[#2C4A3C]">{campsite.rating}</span>
                  </div>
                  <span className="text-sm text-[#5D7B5F]">({campsite.reviews} reviews)</span>
                </div>

                {/* Amenities */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {campsite.amenities.map((amenity) => {
                    const { icon: Icon, label } = amenityIcons[amenity];
                    return (
                      <div 
                        key={amenity}
                        className="flex items-center gap-1 bg-[#A8B9A3]/20 px-2 py-1 rounded-md"
                        title={label}
                      >
                        <Icon className="h-4 w-4 text-[#5D7B5F]" />
                      </div>
                    );
                  })}
                </div>

                <div className="text-sm text-[#5D7B5F] mb-4">
                  {campsite.distance} miles away
                </div>

                <button className="w-full bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] py-2 px-4 rounded-lg transition-colors min-h-[44px]">
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
