import { MessageCircle, ThumbsUp, TrendingUp, User, Clock } from 'lucide-react';

interface ForumTopic {
  id: number;
  category: string;
  title: string;
  author: string;
  avatar: string;
  timestamp: string;
  replies: number;
  likes: number;
  trending: boolean;
}

const forumTopics: ForumTopic[] = [
  {
    id: 1,
    category: 'Gear Reviews',
    title: 'Best budget-friendly tents for beginners? Looking for recommendations!',
    author: 'Sarah Johnson',
    avatar: 'SJ',
    timestamp: '2 hours ago',
    replies: 24,
    likes: 45,
    trending: true
  },
  {
    id: 2,
    category: 'Trip Planning',
    title: 'Yosemite in July - What to expect and must-see spots?',
    author: 'Mike Chen',
    avatar: 'MC',
    timestamp: '5 hours ago',
    replies: 18,
    likes: 32,
    trending: true
  },
  {
    id: 3,
    category: 'Campfire Stories',
    title: 'Our unexpected encounter with wildlife at Yellowstone',
    author: 'Emma Wilson',
    avatar: 'EW',
    timestamp: '1 day ago',
    replies: 56,
    likes: 89,
    trending: true
  },
  {
    id: 4,
    category: 'Tips & Tricks',
    title: 'Meal prep ideas for 5-day backcountry camping',
    author: 'James Taylor',
    avatar: 'JT',
    timestamp: '1 day ago',
    replies: 31,
    likes: 67,
    trending: false
  },
  {
    id: 5,
    category: 'Safety',
    title: 'Essential first aid items every camper should carry',
    author: 'Dr. Lisa Park',
    avatar: 'LP',
    timestamp: '2 days ago',
    replies: 42,
    likes: 102,
    trending: false
  },
  {
    id: 6,
    category: 'Photography',
    title: 'Captured the most amazing sunrise at Crystal Lake!',
    author: 'David Brown',
    avatar: 'DB',
    timestamp: '3 days ago',
    replies: 15,
    likes: 78,
    trending: false
  }
];

const categories = [
  'All Topics',
  'Gear Reviews',
  'Trip Planning',
  'Campfire Stories',
  'Tips & Tricks',
  'Safety',
  'Photography'
];

export function CommunityForum() {
  return (
    <section id="community" className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[#2C4A3C] mb-2">Community Forum</h2>
          <p className="text-[#5D7B5F]">Connect with fellow campers, share stories, and get advice</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Categories Sidebar */}
          <div className="space-y-4">
            <div className="bg-white rounded-xl p-5 shadow-md border border-[#A8B9A3]/30">
              <h3 className="font-semibold text-[#2C4A3C] mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    className="w-full text-left px-4 py-2 rounded-lg bg-[#A8B9A3]/20 hover:bg-[#5D7B5F] hover:text-[#F5F2E8] text-[#2C4A3C] transition-colors min-h-[44px]"
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl p-5 shadow-md border border-[#A8B9A3]/30">
              <button className="w-full bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] px-4 py-3 rounded-lg transition-colors min-h-[44px]">
                Start New Discussion
              </button>
            </div>
          </div>

          {/* Forum Topics */}
          <div className="lg:col-span-3 space-y-4">
            {forumTopics.map((topic) => (
              <div
                key={topic.id}
                className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow border border-[#A8B9A3]/30 cursor-pointer"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-[#5D7B5F] flex items-center justify-center text-[#F5F2E8] font-semibold">
                      {topic.avatar}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-[#2C4A3C]">{topic.author}</span>
                        <span className="text-xs text-[#5D7B5F]">•</span>
                        <span className="text-xs text-[#5D7B5F] flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {topic.timestamp}
                        </span>
                      </div>
                      <span className="inline-block mt-1 text-xs px-2 py-1 bg-[#A8B9A3]/20 text-[#5D7B5F] rounded">
                        {topic.category}
                      </span>
                    </div>
                  </div>
                  {topic.trending && (
                    <div className="flex items-center gap-1 text-[#5D7B5F] text-sm">
                      <TrendingUp className="h-4 w-4" />
                      <span className="font-semibold">Trending</span>
                    </div>
                  )}
                </div>

                <h3 className="text-lg font-semibold text-[#2C4A3C] mb-4 hover:text-[#5D7B5F] transition-colors">
                  {topic.title}
                </h3>

                <div className="flex items-center gap-6 text-sm text-[#5D7B5F]">
                  <div className="flex items-center gap-2">
                    <MessageCircle className="h-4 w-4" />
                    <span>{topic.replies} replies</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ThumbsUp className="h-4 w-4" />
                    <span>{topic.likes} likes</span>
                  </div>
                  <button className="ml-auto text-[#5D7B5F] hover:text-[#2C4A3C] font-semibold transition-colors">
                    Join Discussion →
                  </button>
                </div>
              </div>
            ))}

            {/* Load More Button */}
            <div className="flex justify-center pt-4">
              <button className="px-8 py-3 bg-[#A8B9A3]/30 hover:bg-[#5D7B5F] text-[#2C4A3C] hover:text-[#F5F2E8] rounded-lg transition-colors min-h-[44px]">
                Load More Discussions
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
