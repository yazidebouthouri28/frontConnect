import { Calendar, MapPin, Users, Clock, Ticket } from 'lucide-react';

interface Event {
  id: number;
  title: string;
  type: 'workshop' | 'trip' | 'festival';
  date: string;
  time: string;
  location: string;
  image: string;
  participants: number;
  maxParticipants: number;
  price: number;
  organizer: string;
}

const events: Event[] = [
  {
    id: 1,
    title: 'Wilderness Survival Skills Workshop',
    type: 'workshop',
    date: 'Feb 15, 2026',
    time: '9:00 AM - 4:00 PM',
    location: 'Yosemite National Park, CA',
    image: 'https://images.unsplash.com/photo-1758272960287-002f5db978dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwZ3JvdXAlMjBmcmllbmRzJTIwY2FtcGZpcmV8ZW58MXx8fHwxNzY5NjExMDQ3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    participants: 18,
    maxParticipants: 25,
    price: 85,
    organizer: 'Adventure Education Co.'
  },
  {
    id: 2,
    title: 'Summer Camping Music Festival',
    type: 'festival',
    date: 'Jul 4-6, 2026',
    time: 'All Day',
    location: 'Lake Tahoe, CA',
    image: 'https://images.unsplash.com/photo-1764449320916-ccfdb8aaef62?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwZmVzdGl2YWwlMjBjYW1waW5nJTIwZXZlbnR8ZW58MXx8fHwxNzY5NjExMDQ4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    participants: 342,
    maxParticipants: 500,
    price: 195,
    organizer: 'Mountain Sounds Events'
  },
  {
    id: 3,
    title: 'Beginner\'s Backcountry Group Trip',
    type: 'trip',
    date: 'Mar 22-24, 2026',
    time: '3 Days / 2 Nights',
    location: 'Rocky Mountain NP, CO',
    image: 'https://images.unsplash.com/photo-1758272960287-002f5db978dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwZ3JvdXAlMjBmcmllbmRzJTIwY2FtcGZpcmV8ZW58MXx8fHwxNzY5NjExMDQ3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    participants: 8,
    maxParticipants: 12,
    price: 250,
    organizer: 'Peak Adventures'
  },
  {
    id: 4,
    title: 'Family Camping Weekend',
    type: 'trip',
    date: 'Apr 12-14, 2026',
    time: 'Weekend',
    location: 'Sequoia National Park, CA',
    image: 'https://images.unsplash.com/photo-1758272960287-002f5db978dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwZ3JvdXAlMjBmcmllbmRzJTIwY2FtcGZpcmV8ZW58MXx8fHwxNzY5NjExMDQ3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    participants: 24,
    maxParticipants: 30,
    price: 120,
    organizer: 'Family Outdoors Club'
  },
  {
    id: 5,
    title: 'Photography & Nature Workshop',
    type: 'workshop',
    date: 'May 8, 2026',
    time: '6:00 AM - 2:00 PM',
    location: 'Grand Canyon NP, AZ',
    image: 'https://images.unsplash.com/photo-1764449320916-ccfdb8aaef62?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwZmVzdGl2YWwlMjBjYW1waW5nJTIwZXZlbnR8ZW58MXx8fHwxNzY5NjExMDQ4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    participants: 12,
    maxParticipants: 15,
    price: 95,
    organizer: 'Wilderness Photography Co.'
  },
  {
    id: 6,
    title: 'Mountain Summit Challenge',
    type: 'trip',
    date: 'Jun 15-18, 2026',
    time: '4 Days / 3 Nights',
    location: 'Mount Rainier, WA',
    image: 'https://images.unsplash.com/photo-1758272960287-002f5db978dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwZ3JvdXAlMjBmcmllbmRzJTIwY2FtcGZpcmV8ZW58MXx8fHwxNzY5NjExMDQ3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    participants: 6,
    maxParticipants: 10,
    price: 450,
    organizer: 'Summit Seekers'
  }
];

const eventTypeColors = {
  workshop: 'bg-blue-100 text-blue-700',
  trip: 'bg-green-100 text-green-700',
  festival: 'bg-purple-100 text-purple-700'
};

export function EventsManagement() {
  return (
    <section id="events" className="py-16 px-4 sm:px-6 lg:px-8 bg-[#A8B9A3]/20">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[#2C4A3C] mb-2">Upcoming Events</h2>
          <p className="text-[#5D7B5F]">Join camping workshops, group trips, and outdoor festivals</p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-3 mb-8">
          <button className="px-6 py-2 bg-[#5D7B5F] text-[#F5F2E8] rounded-lg min-h-[44px]">
            All Events
          </button>
          <button className="px-6 py-2 bg-white text-[#2C4A3C] rounded-lg hover:bg-[#A8B9A3]/20 transition-colors min-h-[44px]">
            Workshops
          </button>
          <button className="px-6 py-2 bg-white text-[#2C4A3C] rounded-lg hover:bg-[#A8B9A3]/20 transition-colors min-h-[44px]">
            Group Trips
          </button>
          <button className="px-6 py-2 bg-white text-[#2C4A3C] rounded-lg hover:bg-[#A8B9A3]/20 transition-colors min-h-[44px]">
            Festivals
          </button>
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event) => (
            <div
              key={event.id}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-[#A8B9A3]/30"
            >
              {/* Event Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={event.image}
                  alt={event.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
                <div className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-semibold ${eventTypeColors[event.type]}`}>
                  {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                </div>
              </div>

              {/* Event Details */}
              <div className="p-5">
                <h3 className="text-xl font-semibold text-[#2C4A3C] mb-3">
                  {event.title}
                </h3>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-[#5D7B5F]">
                    <Calendar className="h-4 w-4" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#5D7B5F]">
                    <Clock className="h-4 w-4" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#5D7B5F]">
                    <MapPin className="h-4 w-4" />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#5D7B5F]">
                    <Users className="h-4 w-4" />
                    <span>{event.participants}/{event.maxParticipants} participants</span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="w-full bg-[#A8B9A3]/30 rounded-full h-2">
                    <div
                      className="bg-[#5D7B5F] h-2 rounded-full transition-all"
                      style={{ width: `${(event.participants / event.maxParticipants) * 100}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-[#5D7B5F]">Organized by</p>
                    <p className="font-semibold text-[#2C4A3C]">{event.organizer}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-[#2C4A3C]">${event.price}</p>
                    <p className="text-xs text-[#5D7B5F]">per person</p>
                  </div>
                </div>

                <button className="w-full bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 min-h-[44px]">
                  <Ticket className="h-5 w-5" />
                  <span>Get Tickets</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* View More Button */}
        <div className="flex justify-center mt-8">
          <button className="px-8 py-3 bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] rounded-lg transition-colors min-h-[44px]">
            View All Events
          </button>
        </div>
      </div>
    </section>
  );
}
