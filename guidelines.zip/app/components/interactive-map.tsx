import { MapPin, Navigation, Layers, ZoomIn, ZoomOut } from 'lucide-react';
import { useState } from 'react';

interface MapLocation {
  id: number;
  name: string;
  type: 'campsite' | 'rental' | 'event';
  lat: number;
  lng: number;
  available: boolean;
}

const locations: MapLocation[] = [
  { id: 1, name: 'Pine Valley', type: 'campsite', lat: 37.7, lng: -119.5, available: true },
  { id: 2, name: 'Crystal Lake', type: 'campsite', lat: 39.2, lng: -120.1, available: true },
  { id: 3, name: 'Mountain Peak', type: 'campsite', lat: 40.3, lng: -105.7, available: false },
  { id: 4, name: 'Gear Rental Shop', type: 'rental', lat: 37.9, lng: -119.8, available: true },
  { id: 5, name: 'Summer Camping Festival', type: 'event', lat: 38.5, lng: -119.3, available: true },
];

export function InteractiveMap() {
  const [selectedType, setSelectedType] = useState<'all' | 'campsite' | 'rental' | 'event'>('all');
  const [showRoutes, setShowRoutes] = useState(false);

  const filteredLocations = selectedType === 'all' 
    ? locations 
    : locations.filter(loc => loc.type === selectedType);

  return (
    <section id="map" className="py-16 px-4 sm:px-6 lg:px-8 bg-[#A8B9A3]/20">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[#2C4A3C] mb-2">Interactive Map</h2>
          <p className="text-[#5D7B5F]">Explore campsites, rental locations, and event venues</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Map Controls Sidebar */}
          <div className="space-y-4">
            {/* Filter Options */}
            <div className="bg-white rounded-xl p-5 shadow-md border border-[#A8B9A3]/30">
              <h3 className="font-semibold text-[#2C4A3C] mb-4 flex items-center gap-2">
                <Layers className="h-5 w-5" />
                Filter Locations
              </h3>
              <div className="space-y-2">
                <button
                  onClick={() => setSelectedType('all')}
                  className={`w-full text-left px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                    selectedType === 'all' 
                      ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                      : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                  }`}
                >
                  All Locations
                </button>
                <button
                  onClick={() => setSelectedType('campsite')}
                  className={`w-full text-left px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                    selectedType === 'campsite' 
                      ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                      : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                  }`}
                >
                  Campsites
                </button>
                <button
                  onClick={() => setSelectedType('rental')}
                  className={`w-full text-left px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                    selectedType === 'rental' 
                      ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                      : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                  }`}
                >
                  Equipment Rentals
                </button>
                <button
                  onClick={() => setSelectedType('event')}
                  className={`w-full text-left px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                    selectedType === 'event' 
                      ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                      : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                  }`}
                >
                  Event Venues
                </button>
              </div>
            </div>

            {/* Route Options */}
            <div className="bg-white rounded-xl p-5 shadow-md border border-[#A8B9A3]/30">
              <h3 className="font-semibold text-[#2C4A3C] mb-4 flex items-center gap-2">
                <Navigation className="h-5 w-5" />
                Route Planning
              </h3>
              <button
                onClick={() => setShowRoutes(!showRoutes)}
                className={`w-full px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                  showRoutes 
                    ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                    : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                }`}
              >
                {showRoutes ? 'Hide Routes' : 'Show Routes'}
              </button>
              <div className="mt-4 space-y-2">
                <div className="text-sm text-[#5D7B5F]">
                  <div className="flex justify-between py-1">
                    <span>Total Distance:</span>
                    <span className="font-semibold text-[#2C4A3C]">42.5 mi</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span>Est. Travel Time:</span>
                    <span className="font-semibold text-[#2C4A3C]">1h 15m</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Location List */}
            <div className="bg-white rounded-xl p-5 shadow-md border border-[#A8B9A3]/30">
              <h3 className="font-semibold text-[#2C4A3C] mb-4">Nearby Locations</h3>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {filteredLocations.map((location) => (
                  <div 
                    key={location.id}
                    className="p-3 bg-[#A8B9A3]/10 rounded-lg hover:bg-[#A8B9A3]/20 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-2">
                        <MapPin className="h-4 w-4 text-[#5D7B5F] mt-1" />
                        <div>
                          <p className="font-medium text-[#2C4A3C] text-sm">{location.name}</p>
                          <p className="text-xs text-[#5D7B5F] capitalize">{location.type}</p>
                        </div>
                      </div>
                      {location.available && (
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                          Available
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Map Display */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl overflow-hidden shadow-lg border border-[#A8B9A3]/30">
              {/* Map Controls */}
              <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
                <button className="bg-white p-2 rounded-lg shadow-md hover:bg-[#A8B9A3]/20 transition-colors">
                  <ZoomIn className="h-5 w-5 text-[#2C4A3C]" />
                </button>
                <button className="bg-white p-2 rounded-lg shadow-md hover:bg-[#A8B9A3]/20 transition-colors">
                  <ZoomOut className="h-5 w-5 text-[#2C4A3C]" />
                </button>
              </div>

              {/* Simplified Map Visualization */}
              <div className="relative w-full h-[600px] bg-gradient-to-br from-[#A8B9A3]/20 to-[#5D7B5F]/20">
                {/* Map placeholder with pins */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-16 w-16 text-[#5D7B5F] mx-auto mb-4" />
                    <p className="text-[#2C4A3C] font-semibold">Interactive Map View</p>
                    <p className="text-sm text-[#5D7B5F] mt-2">
                      Showing {filteredLocations.length} locations
                    </p>
                  </div>
                </div>

                {/* Mock map pins */}
                {filteredLocations.map((location, index) => (
                  <div
                    key={location.id}
                    className="absolute"
                    style={{
                      left: `${20 + index * 15}%`,
                      top: `${30 + (index % 3) * 20}%`
                    }}
                  >
                    <div className="relative group cursor-pointer">
                      <MapPin 
                        className={`h-8 w-8 ${
                          location.type === 'campsite' ? 'text-[#2C4A3C]' :
                          location.type === 'rental' ? 'text-[#5D7B5F]' :
                          'text-[#A8B9A3]'
                        } drop-shadow-lg hover:scale-110 transition-transform`}
                        fill="currentColor"
                      />
                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-white rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                        <p className="text-sm font-semibold text-[#2C4A3C]">{location.name}</p>
                        <p className="text-xs text-[#5D7B5F] capitalize">{location.type}</p>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Route lines if enabled */}
                {showRoutes && filteredLocations.length > 1 && (
                  <svg className="absolute inset-0 w-full h-full pointer-events-none">
                    {filteredLocations.slice(0, -1).map((_, index) => (
                      <line
                        key={index}
                        x1={`${20 + index * 15}%`}
                        y1={`${30 + (index % 3) * 20}%`}
                        x2={`${20 + (index + 1) * 15}%`}
                        y2={`${30 + ((index + 1) % 3) * 20}%`}
                        stroke="#5D7B5F"
                        strokeWidth="2"
                        strokeDasharray="5,5"
                        opacity="0.6"
                      />
                    ))}
                  </svg>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
