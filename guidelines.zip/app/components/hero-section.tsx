import { Search, MapPin, Calendar } from 'lucide-react';
import { useState } from 'react';

export function HeroSection() {
  const [searchData, setSearchData] = useState({
    location: '',
    checkIn: '',
    checkOut: '',
    accommodationType: 'tent'
  });

  return (
    <section id="home" className="relative h-[600px] overflow-hidden">
      {/* Hero Image */}
      <div className="absolute inset-0">
        <img 
          src="https://images.unsplash.com/photo-1657038455340-d95a1cc49db8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGNhbXBpbmclMjB0ZW50JTIwc3VucmlzZXxlbnwxfHx8fDE3Njk2MTA5MDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Mountain camping"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#2C4A3C]/80 to-[#2C4A3C]/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
        <div className="max-w-3xl">
          <h1 className="mb-6 text-4xl md:text-5xl lg:text-6xl font-bold text-[#F5F2E8] leading-tight">
            CAMP IS MORE THAN JUST A WORD,<br />IT'S AN EXPERIENCE!
          </h1>
          <p className="mb-8 text-lg md:text-xl text-[#F5F2E8]/90">
            Discover unforgettable camping locations, connect with fellow adventurers, and create memories that last a lifetime.
          </p>

          {/* Search Bar */}
          <div className="bg-white rounded-xl shadow-2xl p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Location */}
              <div className="space-y-2">
                <label className="text-sm text-[#2C4A3C] block">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-[#5D7B5F]" />
                  <input
                    type="text"
                    placeholder="Where to?"
                    value={searchData.location}
                    onChange={(e) => setSearchData({...searchData, location: e.target.value})}
                    className="w-full pl-10 pr-4 py-3 border border-[#A8B9A3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5D7B5F]"
                  />
                </div>
              </div>

              {/* Check-in */}
              <div className="space-y-2">
                <label className="text-sm text-[#2C4A3C] block">Check-in</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-[#5D7B5F]" />
                  <input
                    type="date"
                    value={searchData.checkIn}
                    onChange={(e) => setSearchData({...searchData, checkIn: e.target.value})}
                    className="w-full pl-10 pr-4 py-3 border border-[#A8B9A3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5D7B5F]"
                  />
                </div>
              </div>

              {/* Check-out */}
              <div className="space-y-2">
                <label className="text-sm text-[#2C4A3C] block">Check-out</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-[#5D7B5F]" />
                  <input
                    type="date"
                    value={searchData.checkOut}
                    onChange={(e) => setSearchData({...searchData, checkOut: e.target.value})}
                    className="w-full pl-10 pr-4 py-3 border border-[#A8B9A3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5D7B5F]"
                  />
                </div>
              </div>

              {/* Accommodation Type */}
              <div className="space-y-2">
                <label className="text-sm text-[#2C4A3C] block">Type</label>
                <select
                  value={searchData.accommodationType}
                  onChange={(e) => setSearchData({...searchData, accommodationType: e.target.value})}
                  className="w-full px-4 py-3 border border-[#A8B9A3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5D7B5F]"
                >
                  <option value="tent">Tent</option>
                  <option value="rv">RV/Camper</option>
                  <option value="cabin">Cabin</option>
                  <option value="glamping">Glamping</option>
                </select>
              </div>
            </div>

            {/* Search Button */}
            <button className="mt-6 w-full md:w-auto bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] px-8 py-3 rounded-lg transition-colors flex items-center justify-center gap-2 min-h-[44px]">
              <Search className="h-5 w-5" />
              <span>Search Campsites</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
