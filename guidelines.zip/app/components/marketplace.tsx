import { Star, ShoppingCart, Tag, Award } from 'lucide-react';
import { useState } from 'react';

interface Product {
  id: number;
  name: string;
  category: string;
  image: string;
  price: number;
  rentalPrice?: number;
  rating: number;
  reviews: number;
  inStock: boolean;
  loyaltyPoints: number;
  featured: boolean;
}

const products: Product[] = [
  {
    id: 1,
    name: '4-Person Family Tent',
    category: 'Tents',
    image: 'https://images.unsplash.com/photo-1627820988643-8077d82eed7d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwdGVudCUyMGVxdWlwbWVudCUyMG91dGRvb3IlMjBnZWFyfGVufDF8fHx8MTc2OTYxMTEyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 299,
    rentalPrice: 45,
    rating: 4.7,
    reviews: 128,
    inStock: true,
    loyaltyPoints: 299,
    featured: true
  },
  {
    id: 2,
    name: 'Premium Sleeping Bag',
    category: 'Sleeping Gear',
    image: 'https://images.unsplash.com/photo-1700004583893-981e311b3501?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbGVlcGluZyUyMGJhZyUyMGNhbXBpbmclMjBiYWNrcGFja3xlbnwxfHx8fDE3Njk2MTExMjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 149,
    rentalPrice: 25,
    rating: 4.9,
    reviews: 256,
    inStock: true,
    loyaltyPoints: 149,
    featured: true
  },
  {
    id: 3,
    name: 'Portable Camp Stove',
    category: 'Cooking',
    image: 'https://images.unsplash.com/photo-1619035226152-81e29823b8d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwc3RvdmUlMjBjb29rd2FyZSUyMGdlYXJ8ZW58MXx8fHwxNzY5NjExMTIxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 89,
    rentalPrice: 15,
    rating: 4.6,
    reviews: 94,
    inStock: true,
    loyaltyPoints: 89,
    featured: false
  },
  {
    id: 4,
    name: '65L Hiking Backpack',
    category: 'Backpacks',
    image: 'https://images.unsplash.com/photo-1700004583893-981e311b3501?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbGVlcGluZyUyMGJhZyUyMGNhbXBpbmclMjBiYWNrcGFja3xlbnwxfHx8fDE3Njk2MTExMjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 179,
    rentalPrice: 30,
    rating: 4.8,
    reviews: 187,
    inStock: true,
    loyaltyPoints: 179,
    featured: true
  },
  {
    id: 5,
    name: 'LED Camping Lantern Set',
    category: 'Lighting',
    image: 'https://images.unsplash.com/photo-1627820988643-8077d82eed7d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwdGVudCUyMGVxdWlwbWVudCUyMG91dGRvb3IlMjBnZWFyfGVufDF8fHx8MTc2OTYxMTEyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 45,
    rating: 4.5,
    reviews: 312,
    inStock: true,
    loyaltyPoints: 45,
    featured: false
  },
  {
    id: 6,
    name: 'Water Filtration System',
    category: 'Water & Hydration',
    image: 'https://images.unsplash.com/photo-1619035226152-81e29823b8d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwc3RvdmUlMjBjb29rd2FyZSUyMGdlYXJ8ZW58MXx8fHwxNzY5NjExMTIxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 79,
    rating: 4.9,
    reviews: 428,
    inStock: true,
    loyaltyPoints: 79,
    featured: false
  }
];

export function Marketplace() {
  const [viewMode, setViewMode] = useState<'buy' | 'rent'>('buy');

  return (
    <section id="marketplace" className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[#2C4A3C] mb-2">Camping Gear Marketplace</h2>
          <p className="text-[#5D7B5F]">Buy or rent high-quality camping equipment</p>
        </div>

        {/* Buy/Rent Toggle & Filters */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          {/* Toggle */}
          <div className="inline-flex rounded-lg bg-[#A8B9A3]/20 p-1">
            <button
              onClick={() => setViewMode('buy')}
              className={`px-6 py-2 rounded-md transition-colors min-h-[44px] ${
                viewMode === 'buy'
                  ? 'bg-[#5D7B5F] text-[#F5F2E8]'
                  : 'text-[#2C4A3C] hover:bg-[#A8B9A3]/30'
              }`}
            >
              Buy
            </button>
            <button
              onClick={() => setViewMode('rent')}
              className={`px-6 py-2 rounded-md transition-colors min-h-[44px] ${
                viewMode === 'rent'
                  ? 'bg-[#5D7B5F] text-[#F5F2E8]'
                  : 'text-[#2C4A3C] hover:bg-[#A8B9A3]/30'
              }`}
            >
              Rent
            </button>
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap gap-2">
            <button className="px-4 py-2 bg-[#5D7B5F] text-[#F5F2E8] rounded-lg min-h-[44px]">
              All
            </button>
            <button className="px-4 py-2 bg-white text-[#2C4A3C] rounded-lg hover:bg-[#A8B9A3]/20 transition-colors min-h-[44px]">
              Tents
            </button>
            <button className="px-4 py-2 bg-white text-[#2C4A3C] rounded-lg hover:bg-[#A8B9A3]/20 transition-colors min-h-[44px]">
              Sleeping Gear
            </button>
            <button className="px-4 py-2 bg-white text-[#2C4A3C] rounded-lg hover:bg-[#A8B9A3]/20 transition-colors min-h-[44px]">
              Cooking
            </button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-[#A8B9A3]/30"
            >
              {/* Product Image */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
                {product.featured && (
                  <div className="absolute top-4 left-4 bg-[#5D7B5F] text-[#F5F2E8] px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                    <Tag className="h-3 w-3" />
                    Featured
                  </div>
                )}
                {!product.inStock && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <span className="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold">
                      Out of Stock
                    </span>
                  </div>
                )}
              </div>

              {/* Product Details */}
              <div className="p-5">
                <div className="text-xs text-[#5D7B5F] mb-1">{product.category}</div>
                <h3 className="text-lg font-semibold text-[#2C4A3C] mb-2">
                  {product.name}
                </h3>

                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-[#5D7B5F] text-[#5D7B5F]" />
                    <span className="font-semibold text-[#2C4A3C]">{product.rating}</span>
                  </div>
                  <span className="text-sm text-[#5D7B5F]">({product.reviews} reviews)</span>
                </div>

                {/* Pricing */}
                <div className="mb-4">
                  {viewMode === 'buy' ? (
                    <div>
                      <p className="text-2xl font-bold text-[#2C4A3C]">${product.price}</p>
                      {product.rentalPrice && (
                        <p className="text-xs text-[#5D7B5F]">or rent for ${product.rentalPrice}/day</p>
                      )}
                    </div>
                  ) : product.rentalPrice ? (
                    <div>
                      <p className="text-2xl font-bold text-[#2C4A3C]">${product.rentalPrice}/day</p>
                      <p className="text-xs text-[#5D7B5F]">Buy for ${product.price}</p>
                    </div>
                  ) : (
                    <p className="text-sm text-[#5D7B5F]">Not available for rent</p>
                  )}
                </div>

                {/* Loyalty Points */}
                <div className="flex items-center gap-2 text-sm text-[#5D7B5F] mb-4">
                  <Award className="h-4 w-4" />
                  <span>Earn {product.loyaltyPoints} points</span>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2">
                  <button 
                    disabled={!product.inStock}
                    className="w-full bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:bg-[#A8B9A3] disabled:cursor-not-allowed min-h-[44px]"
                  >
                    <ShoppingCart className="h-5 w-5" />
                    <span>{viewMode === 'buy' ? 'Add to Cart' : 'Rent Now'}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Loyalty Program Banner */}
        <div className="mt-12 bg-gradient-to-r from-[#2C4A3C] to-[#5D7B5F] rounded-xl p-8 text-center text-[#F5F2E8]">
          <Award className="h-12 w-12 mx-auto mb-4" />
          <h3 className="text-2xl font-bold mb-2">Join Our Loyalty Program</h3>
          <p className="mb-6">Earn points on every purchase and unlock exclusive member discounts</p>
          <button className="bg-[#F5F2E8] text-[#2C4A3C] px-8 py-3 rounded-lg font-semibold hover:bg-white transition-colors min-h-[44px]">
            Learn More About Rewards
          </button>
        </div>
      </div>
    </section>
  );
}
