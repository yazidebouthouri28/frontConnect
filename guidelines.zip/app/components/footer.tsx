import { Mountain, Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#2C4A3C] text-[#F5F2E8] mt-auto">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Mountain className="h-8 w-8" />
              <span className="text-xl font-bold">CampConnect</span>
            </div>
            <p className="text-[#A8B9A3] text-sm">
              Your gateway to unforgettable outdoor adventures and camping experiences.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4 font-semibold">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#home" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#campsites" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                  Campsites
                </a>
              </li>
              <li>
                <a href="#marketplace" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                  Marketplace
                </a>
              </li>
              <li>
                <a href="#events" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                  Events
                </a>
              </li>
            </ul>
          </div>

          {/* More Links */}
          <div>
            <h3 className="mb-4 font-semibold">Community</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#community" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                  Forum
                </a>
              </li>
              <li>
                <a href="#map" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                  Map
                </a>
              </li>
              <li>
                <a href="#" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors">
                  About Us
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4 font-semibold">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 text-[#A8B9A3]">
                <Mail className="h-4 w-4" />
                <span>hello@campconnect.com</span>
              </li>
              <li className="flex items-center gap-2 text-[#A8B9A3]">
                <Phone className="h-4 w-4" />
                <span>1-800-CAMP-NOW</span>
              </li>
              <li className="flex items-center gap-2 text-[#A8B9A3]">
                <MapPin className="h-4 w-4" />
                <span>123 Adventure Blvd<br />Mountain View, CA 94043</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-[#5D7B5F]/30 text-center text-sm text-[#A8B9A3]">
          <p>&copy; {new Date().getFullYear()} CampConnect. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
