import { 
  Users, 
  DollarSign, 
  TrendingUp, 
  Activity,
  Tent,
  ShoppingBag,
  Calendar,
  MessageSquare,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const statsCards = [
  {
    title: 'Utilisateurs Totaux',
    value: '12,482',
    change: '+12.5%',
    trend: 'up',
    icon: Users,
    color: 'text-blue-600',
    bgColor: 'bg-blue-100'
  },
  {
    title: 'Revenus du Mois',
    value: '€45,280',
    change: '+8.2%',
    trend: 'up',
    icon: DollarSign,
    color: 'text-green-600',
    bgColor: 'bg-green-100'
  },
  {
    title: 'Réservations Actives',
    value: '324',
    change: '+15.3%',
    trend: 'up',
    icon: Tent,
    color: 'text-purple-600',
    bgColor: 'bg-purple-100'
  },
  {
    title: 'Taux de Conversion',
    value: '3.8%',
    change: '-2.1%',
    trend: 'down',
    icon: TrendingUp,
    color: 'text-orange-600',
    bgColor: 'bg-orange-100'
  }
];

const revenueData = [
  { name: 'Jan', revenus: 28000, reservations: 145 },
  { name: 'Fév', revenus: 32000, reservations: 168 },
  { name: 'Mar', revenus: 35000, reservations: 192 },
  { name: 'Avr', revenus: 38000, reservations: 210 },
  { name: 'Mai', revenus: 42000, reservations: 234 },
  { name: 'Jun', revenus: 45280, reservations: 267 }
];

const categoryData = [
  { name: 'Réservations Sites', value: 45 },
  { name: 'Marketplace', value: 30 },
  { name: 'Événements', value: 15 },
  { name: 'Services Divers', value: 10 }
];

const COLORS = ['#2C4A3C', '#5D7B5F', '#A8B9A3', '#F5F2E8'];

const recentActivities = [
  {
    id: 1,
    type: 'booking',
    user: 'Marie Dubois',
    action: 'a réservé Pine Valley Campground',
    time: 'Il y a 5 min',
    icon: Tent
  },
  {
    id: 2,
    type: 'purchase',
    user: 'Thomas Martin',
    action: 'a acheté une tente 4 personnes',
    time: 'Il y a 12 min',
    icon: ShoppingBag
  },
  {
    id: 3,
    type: 'event',
    user: 'Sophie Laurent',
    action: 's\'est inscrite au Festival d\'été',
    time: 'Il y a 23 min',
    icon: Calendar
  },
  {
    id: 4,
    type: 'forum',
    user: 'Pierre Rousseau',
    action: 'a publié dans le forum',
    time: 'Il y a 1h',
    icon: MessageSquare
  },
  {
    id: 5,
    type: 'user',
    user: 'Julie Bernard',
    action: 'a créé un compte',
    time: 'Il y a 2h',
    icon: Users
  }
];

export function AdminDashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#2C4A3C] mb-2">Tableau de Bord</h1>
        <p className="text-[#5D7B5F]">Vue d'ensemble de votre plateforme CampConnect</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCards.map((stat, index) => {
          const Icon = stat.icon;
          const TrendIcon = stat.trend === 'up' ? ArrowUp : ArrowDown;
          
          return (
            <div key={index} className="bg-white rounded-xl p-6 shadow-md border border-[#A8B9A3]/30">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <Icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className={`flex items-center gap-1 text-sm ${
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  <TrendIcon className="h-4 w-4" />
                  <span className="font-semibold">{stat.change}</span>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-[#2C4A3C] mb-1">{stat.value}</h3>
              <p className="text-sm text-[#5D7B5F]">{stat.title}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <div className="bg-white rounded-xl p-6 shadow-md border border-[#A8B9A3]/30">
          <h3 className="text-xl font-semibold text-[#2C4A3C] mb-6">Revenus & Réservations</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#A8B9A3" opacity={0.3} />
              <XAxis dataKey="name" stroke="#5D7B5F" />
              <YAxis stroke="#5D7B5F" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #A8B9A3',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="revenus" 
                stroke="#2C4A3C" 
                strokeWidth={2}
                name="Revenus (€)"
              />
              <Line 
                type="monotone" 
                dataKey="reservations" 
                stroke="#5D7B5F" 
                strokeWidth={2}
                name="Réservations"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Category Distribution */}
        <div className="bg-white rounded-xl p-6 shadow-md border border-[#A8B9A3]/30">
          <h3 className="text-xl font-semibold text-[#2C4A3C] mb-6">Répartition des Revenus</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-white rounded-xl p-6 shadow-md border border-[#A8B9A3]/30">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold text-[#2C4A3C]">Activités Récentes</h3>
          <button className="text-[#5D7B5F] hover:text-[#2C4A3C] font-semibold text-sm transition-colors">
            Voir tout →
          </button>
        </div>
        <div className="space-y-4">
          {recentActivities.map((activity) => {
            const Icon = activity.icon;
            return (
              <div 
                key={activity.id} 
                className="flex items-center gap-4 p-4 hover:bg-[#A8B9A3]/10 rounded-lg transition-colors"
              >
                <div className="p-2 bg-[#A8B9A3]/20 rounded-lg">
                  <Icon className="h-5 w-5 text-[#5D7B5F]" />
                </div>
                <div className="flex-1">
                  <p className="text-[#2C4A3C]">
                    <span className="font-semibold">{activity.user}</span> {activity.action}
                  </p>
                  <p className="text-sm text-[#5D7B5F]">{activity.time}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button className="p-6 bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] rounded-xl transition-colors text-left">
          <Activity className="h-8 w-8 mb-3" />
          <h4 className="font-semibold mb-1">Approuver les Sites</h4>
          <p className="text-sm text-[#A8B9A3]">12 en attente</p>
        </button>
        <button className="p-6 bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] rounded-xl transition-colors text-left">
          <MessageSquare className="h-8 w-8 mb-3" />
          <h4 className="font-semibold mb-1">Modérer le Forum</h4>
          <p className="text-sm text-[#A8B9A3]">8 signalements</p>
        </button>
        <button className="p-6 bg-[#5D7B5F] hover:bg-[#2C4A3C] text-[#F5F2E8] rounded-xl transition-colors text-left">
          <Users className="h-8 w-8 mb-3" />
          <h4 className="font-semibold mb-1">Gérer les Sponsors</h4>
          <p className="text-sm text-[#A8B9A3]">5 nouvelles demandes</p>
        </button>
      </div>
    </div>
  );
}
