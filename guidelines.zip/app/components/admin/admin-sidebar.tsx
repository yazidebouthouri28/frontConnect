import { 
  LayoutDashboard, 
  Users, 
  Tent,
  ShoppingBag, 
  Calendar,
  MessageSquare,
  Award,
  Settings,
  Shield,
  TrendingUp
} from 'lucide-react';
import { useState } from 'react';

interface NavItem {
  id: string;
  label: string;
  icon: any;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Tableau de Bord', icon: LayoutDashboard },
  { id: 'users', label: 'Utilisateurs', icon: Users },
  { id: 'sponsors', label: 'Sponsors & Partenaires', icon: Award },
  { id: 'campsites', label: 'Sites de Camping', icon: Tent },
  { id: 'marketplace', label: 'Marketplace', icon: ShoppingBag },
  { id: 'events', label: 'Événements', icon: Calendar },
  { id: 'moderation', label: 'Modération', icon: Shield },
  { id: 'forum', label: 'Forum', icon: MessageSquare },
  { id: 'reports', label: 'Rapports', icon: TrendingUp },
  { id: 'settings', label: 'Paramètres', icon: Settings }
];

interface AdminSidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export function AdminSidebar({ activeSection, onSectionChange }: AdminSidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <aside 
      className={`bg-[#2C4A3C] text-[#F5F2E8] transition-all duration-300 ${
        isCollapsed ? 'w-20' : 'w-64'
      } flex flex-col`}
    >
      {/* Header */}
      <div className="p-6 border-b border-[#5D7B5F]/30">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div>
              <h2 className="font-bold text-lg">Admin Panel</h2>
              <p className="text-sm text-[#A8B9A3]">CampConnect</p>
            </div>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="text-[#A8B9A3] hover:text-[#F5F2E8] transition-colors"
          >
            <LayoutDashboard className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-6 overflow-y-auto">
        <ul className="space-y-1 px-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onSectionChange(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    isActive
                      ? 'bg-[#5D7B5F] text-[#F5F2E8]'
                      : 'text-[#A8B9A3] hover:bg-[#5D7B5F]/20 hover:text-[#F5F2E8]'
                  }`}
                  title={isCollapsed ? item.label : ''}
                >
                  <Icon className="h-5 w-5 flex-shrink-0" />
                  {!isCollapsed && <span className="font-medium">{item.label}</span>}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-[#5D7B5F]/30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#5D7B5F] flex items-center justify-center text-[#F5F2E8] font-semibold">
            AD
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm truncate">Admin User</p>
              <p className="text-xs text-[#A8B9A3] truncate">admin@campconnect.com</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}
