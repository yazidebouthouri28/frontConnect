import { 
  Search, 
  Filter, 
  Check, 
  X, 
  Eye,
  Calendar,
  DollarSign,
  Users,
  Building2,
  Mail,
  Phone,
  MapPin
} from 'lucide-react';
import { useState } from 'react';

interface Sponsor {
  id: number;
  name: string;
  companyName: string;
  email: string;
  phone: string;
  location: string;
  category: string;
  requestDate: string;
  status: 'pending' | 'approved' | 'rejected';
  budget: number;
  events: string[];
  description: string;
}

const sponsorsList: Sponsor[] = [
  {
    id: 1,
    name: 'Jean Dupont',
    companyName: 'Outdoor Adventures SA',
    email: 'j.dupont@outdoor-adv.fr',
    phone: '+33 1 23 45 67 89',
    location: 'Paris, France',
    category: 'Équipement de camping',
    requestDate: '2026-01-28',
    status: 'pending',
    budget: 15000,
    events: ['Festival d\'été', 'Atelier survie'],
    description: 'Spécialiste en équipement outdoor haut de gamme depuis 15 ans'
  },
  {
    id: 2,
    name: 'Marie Lambert',
    companyName: 'EcoTravel Agency',
    email: 'm.lambert@ecotravel.fr',
    phone: '+33 2 34 56 78 90',
    location: 'Lyon, France',
    category: 'Agence de voyage',
    requestDate: '2026-01-25',
    status: 'pending',
    budget: 25000,
    events: ['Randonnée montagne', 'Camp familial'],
    description: 'Agence spécialisée dans le tourisme durable et l\'écotourisme'
  },
  {
    id: 3,
    name: 'Pierre Moreau',
    companyName: 'Mountain Gear Pro',
    email: 'p.moreau@mountain-gear.fr',
    phone: '+33 4 56 78 90 12',
    location: 'Grenoble, France',
    category: 'Équipement montagne',
    requestDate: '2026-01-20',
    status: 'approved',
    budget: 20000,
    events: ['Défi sommet', 'Formation alpinisme'],
    description: 'Fabricant et distributeur d\'équipement de montagne professionnel'
  },
  {
    id: 4,
    name: 'Sophie Petit',
    companyName: 'Nature & Découverte',
    email: 's.petit@nature-dec.fr',
    phone: '+33 5 67 89 01 23',
    location: 'Toulouse, France',
    category: 'Retail outdoor',
    requestDate: '2026-01-15',
    status: 'approved',
    budget: 30000,
    events: ['Tous événements'],
    description: 'Chaîne de magasins spécialisée en produits outdoor et nature'
  },
  {
    id: 5,
    name: 'Luc Bernard',
    companyName: 'Camping Pro Services',
    email: 'l.bernard@camping-pro.fr',
    phone: '+33 6 78 90 12 34',
    location: 'Marseille, France',
    category: 'Services camping',
    requestDate: '2026-01-10',
    status: 'rejected',
    budget: 8000,
    events: [],
    description: 'Fournisseur de services pour campings et aires de loisirs'
  }
];

export function SponsorsManagement() {
  const [selectedSponsor, setSelectedSponsor] = useState<Sponsor | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSponsors = sponsorsList.filter(sponsor => {
    const matchesStatus = filterStatus === 'all' || sponsor.status === filterStatus;
    const matchesSearch = sponsor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sponsor.companyName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleApprove = (id: number) => {
    console.log('Approuvé:', id);
    // Logic to approve sponsor
  };

  const handleReject = (id: number) => {
    console.log('Rejeté:', id);
    // Logic to reject sponsor
  };

  const statusColors = {
    pending: 'bg-yellow-100 text-yellow-700',
    approved: 'bg-green-100 text-green-700',
    rejected: 'bg-red-100 text-red-700'
  };

  const statusLabels = {
    pending: 'En attente',
    approved: 'Approuvé',
    rejected: 'Rejeté'
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#2C4A3C] mb-2">Gestion des Sponsors & Partenaires</h1>
        <p className="text-[#5D7B5F]">Validez et gérez les agences partenaires de CampConnect</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-md border border-[#A8B9A3]/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <Calendar className="h-5 w-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#2C4A3C]">
                {sponsorsList.filter(s => s.status === 'pending').length}
              </p>
              <p className="text-sm text-[#5D7B5F]">En attente</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-md border border-[#A8B9A3]/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <Check className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#2C4A3C]">
                {sponsorsList.filter(s => s.status === 'approved').length}
              </p>
              <p className="text-sm text-[#5D7B5F]">Approuvés</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-md border border-[#A8B9A3]/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <DollarSign className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#2C4A3C]">
                €{(sponsorsList.filter(s => s.status === 'approved').reduce((sum, s) => sum + s.budget, 0) / 1000).toFixed(0)}K
              </p>
              <p className="text-sm text-[#5D7B5F]">Budget total</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-md border border-[#A8B9A3]/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Users className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#2C4A3C]">{sponsorsList.length}</p>
              <p className="text-sm text-[#5D7B5F]">Total partenaires</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white rounded-xl p-6 shadow-md border border-[#A8B9A3]/30">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-[#5D7B5F]" />
            <input
              type="text"
              placeholder="Rechercher par nom ou entreprise..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-[#A8B9A3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5D7B5F]"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                filterStatus === 'all' 
                  ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                  : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
              }`}
            >
              Tous
            </button>
            <button
              onClick={() => setFilterStatus('pending')}
              className={`px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                filterStatus === 'pending' 
                  ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                  : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
              }`}
            >
              En attente
            </button>
            <button
              onClick={() => setFilterStatus('approved')}
              className={`px-4 py-2 rounded-lg transition-colors min-h-[44px] ${
                filterStatus === 'approved' 
                  ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                  : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
              }`}
            >
              Approuvés
            </button>
          </div>
        </div>
      </div>

      {/* Sponsors Table */}
      <div className="bg-white rounded-xl shadow-md border border-[#A8B9A3]/30 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#A8B9A3]/20">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-[#2C4A3C]">Partenaire</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-[#2C4A3C]">Catégorie</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-[#2C4A3C]">Budget</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-[#2C4A3C]">Date demande</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-[#2C4A3C]">Statut</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-[#2C4A3C]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#A8B9A3]/20">
              {filteredSponsors.map((sponsor) => (
                <tr key={sponsor.id} className="hover:bg-[#A8B9A3]/10 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <p className="font-semibold text-[#2C4A3C]">{sponsor.name}</p>
                      <p className="text-sm text-[#5D7B5F]">{sponsor.companyName}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="inline-block px-3 py-1 bg-[#A8B9A3]/20 text-[#2C4A3C] rounded-full text-sm">
                      {sponsor.category}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-semibold text-[#2C4A3C]">
                      €{sponsor.budget.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-[#5D7B5F]">
                    {new Date(sponsor.requestDate).toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${statusColors[sponsor.status]}`}>
                      {statusLabels[sponsor.status]}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedSponsor(sponsor)}
                        className="p-2 text-[#5D7B5F] hover:bg-[#A8B9A3]/20 rounded-lg transition-colors"
                        title="Voir détails"
                      >
                        <Eye className="h-5 w-5" />
                      </button>
                      {sponsor.status === 'pending' && (
                        <>
                          <button
                            onClick={() => handleApprove(sponsor.id)}
                            className="p-2 text-green-600 hover:bg-green-100 rounded-lg transition-colors"
                            title="Approuver"
                          >
                            <Check className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleReject(sponsor.id)}
                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                            title="Rejeter"
                          >
                            <X className="h-5 w-5" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedSponsor && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-[#2C4A3C] mb-1">
                    {selectedSponsor.companyName}
                  </h2>
                  <p className="text-[#5D7B5F]">{selectedSponsor.name}</p>
                </div>
                <button
                  onClick={() => setSelectedSponsor(null)}
                  className="text-[#5D7B5F] hover:text-[#2C4A3C]"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-[#5D7B5F]" />
                    <div>
                      <p className="text-sm text-[#5D7B5F]">Email</p>
                      <p className="text-[#2C4A3C]">{selectedSponsor.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-[#5D7B5F]" />
                    <div>
                      <p className="text-sm text-[#5D7B5F]">Téléphone</p>
                      <p className="text-[#2C4A3C]">{selectedSponsor.phone}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-[#5D7B5F]" />
                  <div>
                    <p className="text-sm text-[#5D7B5F]">Localisation</p>
                    <p className="text-[#2C4A3C]">{selectedSponsor.location}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <DollarSign className="h-5 w-5 text-[#5D7B5F]" />
                  <div>
                    <p className="text-sm text-[#5D7B5F]">Budget proposé</p>
                    <p className="text-2xl font-bold text-[#2C4A3C]">
                      €{selectedSponsor.budget.toLocaleString()}
                    </p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-[#5D7B5F] mb-2">Description</p>
                  <p className="text-[#2C4A3C]">{selectedSponsor.description}</p>
                </div>

                <div>
                  <p className="text-sm text-[#5D7B5F] mb-2">Événements ciblés</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedSponsor.events.map((event, index) => (
                      <span 
                        key={index}
                        className="px-3 py-1 bg-[#A8B9A3]/20 text-[#2C4A3C] rounded-full text-sm"
                      >
                        {event}
                      </span>
                    ))}
                  </div>
                </div>

                {selectedSponsor.status === 'pending' && (
                  <div className="flex gap-3 pt-4">
                    <button
                      onClick={() => {
                        handleApprove(selectedSponsor.id);
                        setSelectedSponsor(null);
                      }}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 min-h-[44px]"
                    >
                      <Check className="h-5 w-5" />
                      <span>Approuver</span>
                    </button>
                    <button
                      onClick={() => {
                        handleReject(selectedSponsor.id);
                        setSelectedSponsor(null);
                      }}
                      className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 min-h-[44px]"
                    >
                      <X className="h-5 w-5" />
                      <span>Rejeter</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
