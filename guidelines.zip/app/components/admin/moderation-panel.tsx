import { 
  Search, 
  Filter, 
  Eye,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Flag,
  MessageSquare,
  ShoppingBag,
  Tent
} from 'lucide-react';
import { useState } from 'react';

interface ModerationItem {
  id: number;
  type: 'campsite' | 'product' | 'forum';
  title: string;
  author: string;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
  reports: number;
  content?: string;
  price?: number;
  location?: string;
}

const moderationItems: ModerationItem[] = [
  {
    id: 1,
    type: 'campsite',
    title: 'Nouveau camping au bord du lac',
    author: 'Pierre Martin',
    date: '2026-02-01',
    status: 'pending',
    reports: 0,
    location: 'Lac d\'Annecy, France',
    content: 'Magnifique emplacement en bordure de lac avec toutes commodités'
  },
  {
    id: 2,
    type: 'forum',
    title: 'Meilleurs spots de camping sauvage?',
    author: 'Marie Dubois',
    date: '2026-01-31',
    status: 'pending',
    reports: 2,
    content: 'Je cherche des recommandations pour du camping sauvage en montagne...'
  },
  {
    id: 3,
    type: 'product',
    title: 'Tente ultra-légère 2 personnes',
    author: 'Shop Outdoor Pro',
    date: '2026-01-30',
    status: 'approved',
    reports: 0,
    price: 249,
    content: 'Tente haute qualité, poids seulement 1.2kg'
  },
  {
    id: 4,
    type: 'forum',
    title: 'Attention aux arnaques location matériel',
    author: 'Thomas Bernard',
    date: '2026-01-29',
    status: 'pending',
    reports: 5,
    content: 'J\'ai été victime d\'une arnaque sur la location de matériel...'
  },
  {
    id: 5,
    type: 'campsite',
    title: 'Camping Les Pins - Mise à jour',
    author: 'Admin Camping Les Pins',
    date: '2026-01-28',
    status: 'approved',
    reports: 0,
    location: 'Ardèche, France',
    content: 'Nouvelles installations sanitaires et aire de jeux pour enfants'
  },
  {
    id: 6,
    type: 'product',
    title: 'Sac de couchage grand froid',
    author: 'Mountain Gear',
    date: '2026-01-27',
    status: 'pending',
    reports: 1,
    price: 179,
    content: 'Température confort -15°C, idéal pour l\'hiver'
  }
];

export function ModerationPanel() {
  const [selectedItem, setSelectedItem] = useState<ModerationItem | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'campsite' | 'product' | 'forum'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredItems = moderationItems.filter(item => {
    const matchesType = filterType === 'all' || item.type === filterType;
    const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.author.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesStatus && matchesSearch;
  });

  const handleApprove = (id: number) => {
    console.log('Approuvé:', id);
  };

  const handleReject = (id: number) => {
    console.log('Rejeté:', id);
  };

  const handleEdit = (id: number) => {
    console.log('Éditer:', id);
  };

  const handleDelete = (id: number) => {
    console.log('Supprimer:', id);
  };

  const typeIcons = {
    campsite: Tent,
    product: ShoppingBag,
    forum: MessageSquare
  };

  const typeLabels = {
    campsite: 'Site de camping',
    product: 'Produit',
    forum: 'Publication forum'
  };

  const typeColors = {
    campsite: 'bg-green-100 text-green-700',
    product: 'bg-blue-100 text-blue-700',
    forum: 'bg-purple-100 text-purple-700'
  };

  const statusColors = {
    pending: 'bg-yellow-100 text-yellow-700',
    approved: 'bg-green-100 text-green-700',
    rejected: 'bg-red-100 text-red-700'
  };

  const statusLabels = {
    pending: 'En attente',
    approved: 'Approuvé',
    rejected: 'Rejeté'
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#2C4A3C] mb-2">Modération du Contenu</h1>
        <p className="text-[#5D7B5F]">Gérez et modérez les publications sur la plateforme</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-md border border-[#A8B9A3]/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#2C4A3C]">
                {moderationItems.filter(i => i.status === 'pending').length}
              </p>
              <p className="text-sm text-[#5D7B5F]">En attente</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-md border border-[#A8B9A3]/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-100 rounded-lg">
              <Flag className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#2C4A3C]">
                {moderationItems.reduce((sum, item) => sum + item.reports, 0)}
              </p>
              <p className="text-sm text-[#5D7B5F]">Signalements</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-md border border-[#A8B9A3]/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <CheckCircle className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#2C4A3C]">
                {moderationItems.filter(i => i.status === 'approved').length}
              </p>
              <p className="text-sm text-[#5D7B5F]">Approuvés</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-md border border-[#A8B9A3]/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-100 rounded-lg">
              <XCircle className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#2C4A3C]">
                {moderationItems.filter(i => i.status === 'rejected').length}
              </p>
              <p className="text-sm text-[#5D7B5F]">Rejetés</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white rounded-xl p-6 shadow-md border border-[#A8B9A3]/30">
        <div className="flex flex-col gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-[#5D7B5F]" />
            <input
              type="text"
              placeholder="Rechercher par titre ou auteur..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-[#A8B9A3] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5D7B5F]"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-sm text-[#5D7B5F]">Type:</span>
              <button
                onClick={() => setFilterType('all')}
                className={`px-4 py-2 rounded-lg transition-colors text-sm min-h-[44px] ${
                  filterType === 'all' 
                    ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                    : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                }`}
              >
                Tous
              </button>
              <button
                onClick={() => setFilterType('campsite')}
                className={`px-4 py-2 rounded-lg transition-colors text-sm min-h-[44px] ${
                  filterType === 'campsite' 
                    ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                    : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                }`}
              >
                Campings
              </button>
              <button
                onClick={() => setFilterType('product')}
                className={`px-4 py-2 rounded-lg transition-colors text-sm min-h-[44px] ${
                  filterType === 'product' 
                    ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                    : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                }`}
              >
                Produits
              </button>
              <button
                onClick={() => setFilterType('forum')}
                className={`px-4 py-2 rounded-lg transition-colors text-sm min-h-[44px] ${
                  filterType === 'forum' 
                    ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                    : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                }`}
              >
                Forum
              </button>
            </div>

            <div className="flex items-center gap-2 ml-auto">
              <span className="text-sm text-[#5D7B5F]">Statut:</span>
              <button
                onClick={() => setFilterStatus('all')}
                className={`px-4 py-2 rounded-lg transition-colors text-sm min-h-[44px] ${
                  filterStatus === 'all' 
                    ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                    : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                }`}
              >
                Tous
              </button>
              <button
                onClick={() => setFilterStatus('pending')}
                className={`px-4 py-2 rounded-lg transition-colors text-sm min-h-[44px] ${
                  filterStatus === 'pending' 
                    ? 'bg-[#5D7B5F] text-[#F5F2E8]' 
                    : 'bg-[#A8B9A3]/20 text-[#2C4A3C] hover:bg-[#A8B9A3]/40'
                }`}
              >
                En attente
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Moderation Items */}
      <div className="space-y-4">
        {filteredItems.map((item) => {
          const TypeIcon = typeIcons[item.type];
          
          return (
            <div 
              key={item.id}
              className="bg-white rounded-xl p-6 shadow-md border border-[#A8B9A3]/30 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className={`p-3 rounded-lg ${typeColors[item.type]}`}>
                    <TypeIcon className="h-6 w-6" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold text-[#2C4A3C]">{item.title}</h3>
                      {item.reports > 0 && (
                        <span className="flex items-center gap-1 px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-semibold">
                          <Flag className="h-3 w-3" />
                          {item.reports}
                        </span>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-3 text-sm text-[#5D7B5F] mb-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${typeColors[item.type]}`}>
                        {typeLabels[item.type]}
                      </span>
                      <span>Par {item.author}</span>
                      <span>•</span>
                      <span>{new Date(item.date).toLocaleDateString('fr-FR')}</span>
                      {item.location && (
                        <>
                          <span>•</span>
                          <span>{item.location}</span>
                        </>
                      )}
                      {item.price && (
                        <>
                          <span>•</span>
                          <span className="font-semibold text-[#2C4A3C]">€{item.price}</span>
                        </>
                      )}
                    </div>
                    
                    <p className="text-[#5D7B5F] text-sm line-clamp-2">{item.content}</p>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[item.status]}`}>
                    {statusLabels[item.status]}
                  </span>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedItem(item)}
                      className="p-2 text-[#5D7B5F] hover:bg-[#A8B9A3]/20 rounded-lg transition-colors"
                      title="Voir détails"
                    >
                      <Eye className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleEdit(item.id)}
                      className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                      title="Éditer"
                    >
                      <Edit className="h-5 w-5" />
                    </button>
                    {item.status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleApprove(item.id)}
                          className="p-2 text-green-600 hover:bg-green-100 rounded-lg transition-colors"
                          title="Approuver"
                        >
                          <CheckCircle className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => handleReject(item.id)}
                          className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                          title="Rejeter"
                        >
                          <XCircle className="h-5 w-5" />
                        </button>
                      </>
                    )}
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                      title="Supprimer"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-[#2C4A3C] mb-2">
                    {selectedItem.title}
                  </h2>
                  <div className="flex items-center gap-2">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${typeColors[selectedItem.type]}`}>
                      {typeLabels[selectedItem.type]}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[selectedItem.status]}`}>
                      {statusLabels[selectedItem.status]}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="text-[#5D7B5F] hover:text-[#2C4A3C]"
                >
                  <XCircle className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-sm text-[#5D7B5F] mb-1">Auteur</p>
                  <p className="text-[#2C4A3C] font-semibold">{selectedItem.author}</p>
                </div>

                <div>
                  <p className="text-sm text-[#5D7B5F] mb-1">Date de publication</p>
                  <p className="text-[#2C4A3C]">{new Date(selectedItem.date).toLocaleDateString('fr-FR')}</p>
                </div>

                {selectedItem.reports > 0 && (
                  <div>
                    <p className="text-sm text-[#5D7B5F] mb-1">Signalements</p>
                    <p className="text-red-600 font-semibold">{selectedItem.reports} signalements</p>
                  </div>
                )}

                <div>
                  <p className="text-sm text-[#5D7B5F] mb-1">Contenu</p>
                  <p className="text-[#2C4A3C] whitespace-pre-wrap">{selectedItem.content}</p>
                </div>

                {selectedItem.status === 'pending' && (
                  <div className="flex gap-3 pt-4">
                    <button
                      onClick={() => {
                        handleApprove(selectedItem.id);
                        setSelectedItem(null);
                      }}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 min-h-[44px]"
                    >
                      <CheckCircle className="h-5 w-5" />
                      <span>Approuver</span>
                    </button>
                    <button
                      onClick={() => {
                        handleReject(selectedItem.id);
                        setSelectedItem(null);
                      }}
                      className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 min-h-[44px]"
                    >
                      <XCircle className="h-5 w-5" />
                      <span>Rejeter</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
