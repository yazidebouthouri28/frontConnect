import { useState } from 'react';
import { AdminSidebar } from '@/app/components/admin/admin-sidebar';
import { AdminDashboard } from '@/app/components/admin/admin-dashboard';
import { SponsorsManagement } from '@/app/components/admin/sponsors-management';
import { ModerationPanel } from '@/app/components/admin/moderation-panel';

export function AdminPanel() {
  const [activeSection, setActiveSection] = useState('dashboard');

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <AdminDashboard />;
      case 'sponsors':
        return <SponsorsManagement />;
      case 'moderation':
      case 'campsites':
      case 'marketplace':
      case 'forum':
        return <ModerationPanel />;
      default:
        return (
          <div className="p-6">
            <div className="bg-white rounded-xl p-12 text-center shadow-md border border-[#A8B9A3]/30">
              <h2 className="text-2xl font-bold text-[#2C4A3C] mb-2">
                Section en développement
              </h2>
              <p className="text-[#5D7B5F]">
                Cette section sera bientôt disponible
              </p>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-[#F5F2E8] overflow-hidden">
      <AdminSidebar 
        activeSection={activeSection} 
        onSectionChange={setActiveSection} 
      />
      <main className="flex-1 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
}
